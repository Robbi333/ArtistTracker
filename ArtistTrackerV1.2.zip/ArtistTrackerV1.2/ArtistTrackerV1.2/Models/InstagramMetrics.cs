﻿using ArtistTrackerV1._2.Models;
using System;
using System.ComponentModel.DataAnnotations;

namespace ArtistTrackerV1._2.Models
{
    public class InstagramMetrics
    {
        public int InstagramMetricsId { get; set; }
        public int ArtistId { get; set; }
        public int Followers { get; set; }
        public int FollowersChange { get; set; }
        public DateTime LastUpdated { get; set; }

        [StringLength(50)]
        public string? InstagramLink { get; set; }

        // Navigation property
        public Artist? Artist { get; set; }
    }
}

﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ArtistTrackerV1._2.Models
{
    public class TikTokMetrics
    {
        public int TikTokMetricsId { get; set; }
        public int ArtistId { get; set; }
        public int Followers { get; set; }
        public int FollowersChange { get; set; }
        public DateTime LastUpdated { get; set; }

        [StringLength(50)]
        public string? TikTokLink { get; set; }

        // Navigation property
        public Artist? Artist { get; set; }
    }
}
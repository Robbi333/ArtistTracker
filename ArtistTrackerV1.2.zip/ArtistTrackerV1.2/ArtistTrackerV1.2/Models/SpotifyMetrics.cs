﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ArtistTrackerV1._2.Models
{
    public class SpotifyMetrics
    {
        public int SpotifyMetricsId { get; set; }
        public int ArtistId { get; set; }
        public int Followers { get; set; }
        public double FollowersChangePercentage { get; set; }
        public int Listeners { get; set; }
        public double ListenersChangePercentage { get; set; }
        public int Streams { get; set; }
        public DateTime LastUpdated { get; set; }

        // Navigation property
        public Artist? Artist { get; set; }
    }
}
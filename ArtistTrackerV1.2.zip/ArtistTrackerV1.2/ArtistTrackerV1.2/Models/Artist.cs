﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ArtistTrackerV1._2.Models
{
    public class Artist
    {
        public int ArtistId { get; set; }

        [Required]
        [StringLength(100)]
        public string? Name { get; set; }

        [StringLength(255)]
        public string? SpotifyProfileLink { get; set; }

        public int SpotifyMonthlyListeners { get; set; }

        [StringLength(50)]
        public string? TikTokLink { get; set; }

        [StringLength(50)]
        public string? InstagramLink { get; set; }

        // Navigation properties
        public SpotifyMetrics? SpotifyMetrics { get; set; }
        public TikTokMetrics? TikTokMetrics { get; set; }
        public InstagramMetrics? InstagramMetrics { get; set; }
    }
}
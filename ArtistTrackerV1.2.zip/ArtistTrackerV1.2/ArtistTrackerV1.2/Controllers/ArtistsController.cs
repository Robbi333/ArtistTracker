﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ArtistTrackerV1._2.Data;
using ArtistTrackerV1._2.Models;
using ArtistTrackerV1._2.Services;

     namespace ArtistTrackerV1._2.Controllers
    {
        public class ArtistsController : Controller
        {
            private readonly ArtistTrackerDbContext _context;
            private readonly SpotifyService _spotifyService; // Declare field for SpotifyService
             private readonly  FollowerCountService _followerCountService;

            public ArtistsController(ArtistTrackerDbContext context, SpotifyService spotifyService, FollowerCountService followerCountService) // Inject SpotifyService
            {
                _context = context;
                _spotifyService = spotifyService; // Assign SpotifyService
                _followerCountService = followerCountService;
        }

            // GET: Artists
            public async Task<IActionResult> Index()
            {
                var artists = await _context.Artists.ToListAsync();

                foreach (var artist in artists)
                {
                    var monthlyListeners = await _spotifyService.GetMonthlyListenersCount(artist.SpotifyProfileLink);
                    artist.SpotifyMonthlyListeners = monthlyListeners;
                }

                return View(artists);
            }

            // GET: Artists/Details/5
            public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var artist = await _context.Artists
                .FirstOrDefaultAsync(m => m.ArtistId == id);
            if (artist == null)
            {
                return NotFound();
            }

            return View(artist);
        }


        // POST: Artists/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ArtistId,Name,SpotifyProfileLink,TikTokUsername,InstagramUsername")] Artist artist)
        {
            if (id != artist.ArtistId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(artist);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArtistExists(artist.ArtistId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(artist);
        }

        // GET: Artists/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var artist = await _context.Artists
                .FirstOrDefaultAsync(m => m.ArtistId == id);
            if (artist == null)
            {
                return NotFound();
            }

            return View(artist);
        }

        // POST: Artists/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var artist = await _context.Artists.FindAsync(id);
            if (artist != null)
            {
                _context.Artists.Remove(artist);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }
        // GET: Artists/GetFollowerCount
        [HttpGet]
        public IActionResult GetFollowerCount()
        {
            return View();
        }

        /// POST: Artists/GetFollowerCount
        [HttpPost]
        public async Task<IActionResult> GetFollowerCount(string url)
        {
            if (string.IsNullOrEmpty(url))
            {
                ModelState.AddModelError("url", "URL is required.");
                return View();
            }

            try
            {
                // Logic to fetch follower count using _followerCountService
                var followerCount = await _followerCountService.GetFollowerCount(url);

                // Once you have the follower count, you can return it to the view
                return View("FollowerCount", followerCount);
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, $"Error: {ex.Message}");
                return View();
            }
        }


        private bool ArtistExists(int id)
        {
            return _context.Artists.Any(e => e.ArtistId == id);
        }
    }
}

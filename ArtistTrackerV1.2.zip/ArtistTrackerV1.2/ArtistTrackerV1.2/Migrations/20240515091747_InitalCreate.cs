﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ArtistTrackerV1._2.Migrations
{
    /// <inheritdoc />
    public partial class InitalCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Artists",
                columns: table => new
                {
                    ArtistId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    SpotifyProfileLink = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    SpotifyMonthlyListeners = table.Column<int>(type: "int", nullable: false),
                    TikTokLink = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    InstagramLink = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Artists", x => x.ArtistId);
                });

            migrationBuilder.CreateTable(
                name: "InstagramMetrics",
                columns: table => new
                {
                    InstagramMetricsId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ArtistId = table.Column<int>(type: "int", nullable: false),
                    Followers = table.Column<int>(type: "int", nullable: false),
                    FollowersChange = table.Column<int>(type: "int", nullable: false),
                    LastUpdated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    InstagramLink = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InstagramMetrics", x => x.InstagramMetricsId);
                    table.ForeignKey(
                        name: "FK_InstagramMetrics_Artists_ArtistId",
                        column: x => x.ArtistId,
                        principalTable: "Artists",
                        principalColumn: "ArtistId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "SpotifyMetrics",
                columns: table => new
                {
                    SpotifyMetricsId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ArtistId = table.Column<int>(type: "int", nullable: false),
                    Followers = table.Column<int>(type: "int", nullable: false),
                    FollowersChangePercentage = table.Column<double>(type: "float", nullable: false),
                    Listeners = table.Column<int>(type: "int", nullable: false),
                    ListenersChangePercentage = table.Column<double>(type: "float", nullable: false),
                    Streams = table.Column<int>(type: "int", nullable: false),
                    LastUpdated = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SpotifyMetrics", x => x.SpotifyMetricsId);
                    table.ForeignKey(
                        name: "FK_SpotifyMetrics_Artists_ArtistId",
                        column: x => x.ArtistId,
                        principalTable: "Artists",
                        principalColumn: "ArtistId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TikTokMetrics",
                columns: table => new
                {
                    TikTokMetricsId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ArtistId = table.Column<int>(type: "int", nullable: false),
                    Followers = table.Column<int>(type: "int", nullable: false),
                    FollowersChange = table.Column<int>(type: "int", nullable: false),
                    LastUpdated = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TikTokLink = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TikTokMetrics", x => x.TikTokMetricsId);
                    table.ForeignKey(
                        name: "FK_TikTokMetrics_Artists_ArtistId",
                        column: x => x.ArtistId,
                        principalTable: "Artists",
                        principalColumn: "ArtistId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_InstagramMetrics_ArtistId",
                table: "InstagramMetrics",
                column: "ArtistId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_SpotifyMetrics_ArtistId",
                table: "SpotifyMetrics",
                column: "ArtistId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_TikTokMetrics_ArtistId",
                table: "TikTokMetrics",
                column: "ArtistId",
                unique: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "InstagramMetrics");

            migrationBuilder.DropTable(
                name: "SpotifyMetrics");

            migrationBuilder.DropTable(
                name: "TikTokMetrics");

            migrationBuilder.DropTable(
                name: "Artists");
        }
    }
}

﻿using System;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

public class FollowerCountService
{
    private readonly HttpClient _httpClient;

    public FollowerCountService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<int> GetFollowerCount(string url)
    {
        try
        {
            // Fetch HTML content of the provided URL
            var htmlContent = await _httpClient.GetStringAsync(url);

            // Apply regex pattern matching to extract follower count
            var followerCount = ExtractFollowerCount(htmlContent);

            return followerCount;
        }
        catch (Exception ex)
        {
            // Log or handle any errors
            Console.WriteLine($"Error fetching follower count: {ex.Message}");
            throw;
        }
    }

    private int ExtractFollowerCount(string htmlContent)
    {
        // Regex pattern to match follower count from meta tag
        var pattern = @"<meta\s+content=""([0-9k KMm\.,]+)\s+Followers";

        // Match the pattern in the HTML content
        var match = Regex.Match(htmlContent, pattern);

        // If a match is found, extract and parse the follower count
        if (match.Success)
        {
            var followerCountStr = match.Groups[1].Value;
            return ParseFollowerCountString(followerCountStr);
        }
        else
        {
            throw new Exception("Follower count not found in HTML content.");
        }
    }

    private int ParseFollowerCountString(string followerCountStr)
    {
        // Replace 'k' with '000' and remove any other non-numeric characters
        var cleanedStr = followerCountStr.Replace("k", "000").Replace(",", "").Replace(".", "").Replace(" ", "");

        // Parse the cleaned string to get the follower count
        if (int.TryParse(cleanedStr, out int followerCount))
        {
            return followerCount;
        }
        else
        {
            throw new Exception("Failed to parse follower count.");
        }
    }
}

﻿using System;
using System.Net.Http;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

public class SpotifyService
{
    private readonly IHttpClientFactory _httpClientFactory;

    public SpotifyService(IHttpClientFactory httpClientFactory)
    {
        _httpClientFactory = httpClientFactory;
    }

    public async Task<int> GetMonthlyListenersCount(string spotifyArtistId)
     {
        var httpClient = _httpClientFactory.CreateClient();
        httpClient.DefaultRequestHeaders.Add("X-RapidAPI-Key", "97430c967cmsha99eeaf97509c62p11222bjsnb6e6fab68d05");
        httpClient.DefaultRequestHeaders.Add("X-RapidAPI-Host", "spotify-artist-monthly-listeners.p.rapidapi.com");

        var requestUrl = $"https://spotify-artist-monthly-listeners.p.rapidapi.com/artists/spotify_artist_monthly_listeners?spotify_artist_id={spotifyArtistId}";

        var response = await httpClient.GetAsync(requestUrl);

        if (response.IsSuccessStatusCode)
        {
            var responseContent = await response.Content.ReadAsStringAsync();

            // Parse JSON response
            var jsonResponse = JsonSerializer.Deserialize<ApiResponse>(responseContent);
            if (jsonResponse != null)
            {
                return jsonResponse.MonthlyListeners;
            }
            else
            {
                throw new Exception("Failed to retrieve monthly listeners count.");
            }
        }
        else
        {
            // Handle error response
            throw new Exception($"Failed to get monthly listeners count. Status code: {response.StatusCode}");
        }
    }

}

public class ApiResponse
{
    public string? Result { get; set; }
    public string? Message { get; set; }
    public string? SpotifyArtistId { get; set; }
    [JsonPropertyName("monthly_listeners")]
    public int MonthlyListeners { get; set; }
}

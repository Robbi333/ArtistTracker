﻿using Microsoft.Extensions.Configuration;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace ArtistTrackerV1._2.Services
{
    public class TikTokService
    {
        private readonly IConfiguration _configuration;
        private readonly HttpClient _httpClient;

        public TikTokService(IConfiguration configuration)
        {
            _configuration = configuration;
            _httpClient = new HttpClient();
        }

        public async Task<int> GetFollowersAsync(string tiktokUsername)
        {
            var apiUrl = $"https://api.tiktok.com/v1/users/{tiktokUsername}/?access_token={_configuration["TikTok:AccessToken"]}";
            var response = await _httpClient.GetStringAsync(apiUrl);
            var json = JObject.Parse(response);
            return json["data"]["followers_count"].Value<int>();
        }

        // Add more methods as needed
    }
}

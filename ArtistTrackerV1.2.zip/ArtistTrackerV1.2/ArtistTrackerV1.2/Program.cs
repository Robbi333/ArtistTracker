using ArtistTrackerV1._2.Data;
using ArtistTrackerV1._2.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);
var configuration = builder.Configuration;

// Configuring DbContext
builder.Services.AddDbContext<ArtistTrackerDbContext>(options =>
{
    var connectionString = configuration.GetConnectionString("DefaultConnection");
    if (connectionString == null)
    {
        throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
    }
    options.UseSqlServer(connectionString);
});

// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient(); // Add this line to register IHttpClientFactory
builder.Services.AddScoped<SpotifyService>(); // Register SpotifyService
builder.Services.AddScoped<FollowerCountService>(); // Register FollowerCountService

var app = builder.Build();

// Seed data on application startup (if needed)
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;

    var dbContext = services.GetRequiredService<ArtistTrackerDbContext>();
    dbContext.Database.Migrate(); // Apply any pending migrations

    // Add seed data initialization logic here
    if (!dbContext.Artists.Any())
    {
        dbContext.Artists.Add(new Artist
        {
            Name = "Test Artist",
            SpotifyProfileLink = "6TJuqcsA3Z6xWu1C85VD7r",
            TikTokLink = "https://www.tiktok.com/@testartist",
            InstagramLink = "https://www.instagram.com/testartist"
        });

        // Add more seed data if needed
        // dbContext.Artists.Add(new Artist { Name = "Another Artist", ... });

        dbContext.SaveChanges();
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

﻿using Microsoft.EntityFrameworkCore;
using ArtistTrackerV1._2.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace ArtistTrackerV1._2.Data
{
    public class ArtistTrackerDbContext : DbContext
    {
        public ArtistTrackerDbContext(DbContextOptions<ArtistTrackerDbContext> options)
            : base(options)
        {
        }

        // DbSet properties for your model classes
        public DbSet<Artist> Artists { get; set; }
        public DbSet<SpotifyMetrics> SpotifyMetrics { get; set; }
        public DbSet<TikTokMetrics> TikTokMetrics { get; set; }
        public DbSet<InstagramMetrics> InstagramMetrics { get; set; }

        // Override OnModelCreating if needed
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Configure one-to-one relationship between Artist and SpotifyMetrics
            modelBuilder.Entity<Artist>()
                .HasOne(a => a.SpotifyMetrics)
                .WithOne(sm => sm.Artist)
                .HasForeignKey<SpotifyMetrics>(sm => sm.ArtistId);

            // Configure one-to-one relationship between Artist and TikTokMetrics
            modelBuilder.Entity<Artist>()
                .HasOne(a => a.TikTokMetrics)
                .WithOne(tm => tm.Artist)
                .HasForeignKey<TikTokMetrics>(tm => tm.ArtistId);

            // Configure one-to-one relationship between Artist and InstagramMetrics
            modelBuilder.Entity<Artist>()
                .HasOne(a => a.InstagramMetrics)
                .WithOne(im => im.Artist)
                .HasForeignKey<InstagramMetrics>(im => im.ArtistId);
        }
    }
}
